export {DataTable, DataEvent, PageEvent, SortEvent} from './lib/DataTable';
export {DefaultSorter} from './lib/DefaultSorter';
export {Paginator} from './lib/Paginator';
export {BootstrapPaginator} from './lib/BootstrapPaginator';

export const DataTableDirectives: any[];