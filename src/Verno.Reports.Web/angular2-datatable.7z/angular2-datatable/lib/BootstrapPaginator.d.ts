import { OnChanges } from "@angular/core";
export declare class BootstrapPaginator implements OnChanges {
    private rowsOnPageSet;
    private mfTable;
    private minRowsOnPage;
    ngOnChanges(changes: any): any;
}
