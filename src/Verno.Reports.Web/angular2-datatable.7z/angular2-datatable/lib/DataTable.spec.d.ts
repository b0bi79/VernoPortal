/// <reference path="../src/typings/browser/ambient/jasmine/index.d.ts" />
